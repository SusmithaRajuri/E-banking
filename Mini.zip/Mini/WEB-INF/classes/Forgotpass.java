import java.io.*;  
import java.sql.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import javax.servlet.ServletException; 
  
public class Forgotpass extends HttpServlet
{  
public void doGet(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException 
{  
  
response.setContentType("text/html");  
PrintWriter out = response.getWriter();  
          
String accno=request.getParameter("acc");  

String phno1=request.getParameter("phno");  


out.print("Hello!!User Password is:");
          
try{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db101","root","susmitha23"  );  
  
PreparedStatement ps=con.prepareStatement("select pass from userreg where acc=? and phno=?"); 
ps.setString(1,accno);
ps.setString(2,phno1);  
ResultSet rs=ps.executeQuery();
while(rs.next())
{
	out.println(rs.getString(1));
}          
}
catch (Exception e2) {out.println(e2);}  
          

}  
  
}  