import java.sql.*;
import javax.sql.*;
import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
public class Login extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
	{	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
			 
			
			String n=request.getParameter("acc");
			
			String p=request.getParameter("pass");
			boolean st=Login1.checkUser(n,p);
			if(st)
				{
        			RequestDispatcher rd=request.getRequestDispatcher("/firstpage.jsp");  
        			rd.forward(request, response);  
    				}  
    				else
				{  
        			out.print("Sorry UserName or Password Error!");  
        			RequestDispatcher rd=request.getRequestDispatcher("/continuetologin.html");  
        			rd.include(request, response);  
                      
       			 	} 
			out.close();
			
    	}  
  
}  
