import java.sql.*;
public class Login1
{
	public static boolean checkUser(String acc,String pass)
	{
	boolean st=false;
	
try
{
	
		
		
		Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db101","root","susmitha23");
		PreparedStatement ps=con.prepareStatement("select * from userreg where acc=? and pass=?");
		ps.setString(1,acc); 
		ps.setString(2,pass); 
		ResultSet rs=ps.executeQuery();
		
		st=rs.next();
}
catch(Exception e){System.out.println(e);}  
	
	return st;
}
}	