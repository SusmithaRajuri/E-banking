import java.sql.*;
import javax.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;
import javax.sql.rowset.*;
import java.io.*;  
public class Profile extends HttpServlet 
{  

	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
	{	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession sess=request.getSession(false);
		String n=(String)sess.getAttribute("accn");
		
		try
		{
		JdbcRowSet rowSet = RowSetProvider.newFactory().createJdbcRowSet();
		Class.forName("com.mysql.jdbc.Driver");  
		 rowSet.setUrl("jdbc:mysql://localhost:3306/db101");  
        	rowSet.setUsername("root");  
        	rowSet.setPassword("susmitha23"); 
		 
        
        	rowSet.setCommand("select * from userreg where acc=?");
		rowSet.setString(1,n);  
		
        rowSet.execute(); 
		 
		
                    
    		while (rowSet.next()) 
		{  
 
                        // Generating cursor Moved event  
                       	out.println("<html>");
			out.println("<table>");
			out.println("<tr>");
			out.println("<td>Account No:</td>");
			out.println("<td>" + rowSet.getString(1)+"</td>"); 
			out.println("</tr>"); 
			out.println("<tr>");
                        out.println("<td>Branch Code:</td> ");
			out.println("<td>" + rowSet.getString(2)+"</td>");
			out.println("</tr>");
			out.println("<tr>");
                        out.println("<td>Country:</td> ");
			out.println("<td>" + rowSet.getString(3)+"</td>");
			out.println("</tr>");   
			out.println("<tr>");
                        out.println("<td>Mail:</td> ");
			out.println("<td>" + rowSet.getString(4)+"</td>");
			out.println("</tr>"); 
			out.println("<tr>");
                        out.println("<td>Phone No:</td> ");
			out.println("<td>" + rowSet.getString(5)+"</td>");
			out.println("</tr>"); 
			out.println("<tr>");
                        out.println("<td>Balance:</td> ");
			out.println("<td>" + rowSet.getString(7)+"</td>");
			out.println("</tr>");  

		}
	}
catch(Exception e)
{
 out.println(e);
}
                        

	}
}