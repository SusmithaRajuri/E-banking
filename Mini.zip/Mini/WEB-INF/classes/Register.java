import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Register extends HttpServlet {
    
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String acc = request.getParameter("acc");
        String bc = request.getParameter("bc");
        String country = request.getParameter("country");
	String mail = request.getParameter("mail");
	String phno = request.getParameter("phno");
	
		
        try{
        
        //loading drivers for mysql
        Class.forName("com.mysql.jdbc.Driver");

	//creating connection with the database 
          Connection  con=DriverManager.getConnection
                     ("jdbc:mysql:/ /localhost:3306/db101","root","susmitha23");

        PreparedStatement ps=con.prepareStatement
                  ("insert into userreg values(?,?,?,?,?)");

        ps.setString(1, acc);
        ps.setString(2, bc);
        ps.setString(3, country);
	ps.setString(4, mail);
	ps.setString(5, phno);
        int i=ps.executeUpdate();
        
          if(i>0)
          {
            out.println("You are sucessfully registered");
		RequestDispatcher rd=request.getRequestDispatcher("/continuetologin.html");  
        			rd.include(request, response);
          }
	else
	{
		out.println("Try Again");
        }
	}
        catch(Exception se)
        {
            se.printStackTrace();
        }
	
      }
  }