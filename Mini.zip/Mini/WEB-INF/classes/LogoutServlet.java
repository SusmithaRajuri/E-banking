import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
public class LogoutServlet extends HttpServlet {  
        public void doGet(HttpServletRequest request, HttpServletResponse response)  
                                throws ServletException, IOException {  
            response.setContentType("text/html");  
            PrintWriter out=response.getWriter(); 
	
	HttpSession session=request.getSession(false);
	session.removeAttribute("accn"); 
        session.invalidate();
	response.setHeader("Cache-Control","no-cache");
response.setDateHeader("Expires", 0); 
response.setHeader("Pragma","no-cache"); 

RequestDispatcher rd=request.getRequestDispatcher("login.html");
	rd.forward(request, response); 

		 
              
            out.print("You are successfully logged out!");  
              
            out.close();  
    }  
}  
 
	