import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class displaycount extends HttpServlet
{
public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
{
ServletContext context = getServletContext();
Integer count= (Integer) context.getAttribute("count");
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
pw.println("<html>");

pw.println("<meta http-equiv=\"Pragma\" content=\"no-cache\">");
pw.println("<body>");
if(count!=null)
{
pw.println("  the current count is " + count.intValue());
}
else
{
pw.println("count not available ");
}
pw.println("</body>");
pw.println("</html>");
pw.close();
}
}
  