import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class counterfilter implements Filter
{
FilterConfig config;
public void init(FilterConfig config)
{
this.config=config;
}

public void doFilter(ServletRequest req, ServletResponse res,FilterChain chain) throws IOException,ServletException
{
ServletContext context=config.getServletContext();
Integer count= (Integer) context.getAttribute("count");
if(count==null)
{
count=new Integer(0);
}

count=new Integer(count.intValue()+1);
context.setAttribute("count",count);
chain.doFilter(req,res);
}
public void destroy()
{}
}
